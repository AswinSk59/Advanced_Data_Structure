#include<stdio.h>
#include<stdlib.h>


void insertb();
void inserte();
void insertp();
void deleteb();
void deletee();
void deletep();
void search();
void display();
struct node   
{  
    int data;  
    struct node *next;   
};  
struct node *head;
int choice,n,temp,loc,i,flag;

int main(){
	printf("\n1.Insert in beginning\n2.Insert in end\n3.Insert at any position\n4.Delete in beginning\n5.Delete in end\n6.Delete at any position\n7.Display\n8.search\n9.Exit");
	printf("\n Enter your choice: ");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:insertb();
		break;
	case 2:inserte();
		break;
	case 3:insertp();
		break;
	case 4:deleteb();
		break;
	case 5:deletee();
		break;
	case 6:deletep();
		break;	
	case 7:display();
		break;
	case 8:search();
		break;	
	case 9:
		exit(1);
	}
}

void insertb()
{  
	struct node *ptr;  
	ptr=(struct node*)malloc(sizeof(struct node*));  
	if(ptr==NULL)  
	{  
		printf("\nOVERFLOW");  
	}  
	else  
	{  
		printf("\nEnter value\n");    
		scanf("%d",&n);    
		ptr->data=n;  
		ptr->next=head;  
		head=ptr;  
		printf("\nNode inserted");  
	}  
	main();
}  

void display()  
{  
	struct node *ptr;  
	ptr=head;   
	if(ptr==NULL)  
	{  
		printf("Empty");  
	}  
	else  
	{  
		printf("\nvalues\n");   
		while (ptr!=NULL)  
		{  
			printf("%d=>",ptr->data);  
			ptr=ptr->next;  
		}  
		printf("\n");
	} 
	main(); 
}  

void deleteb()  
{  
	struct node *ptr;  
	if(head==NULL)  
	{  
		printf("\nList is empty\n");  
	}  
	else   
	{  
		ptr=head;  
		head=ptr->next;  
		free(ptr);  
		printf("\nDeleted from the begining\n");  
	}  
	printf("\n");
	main();
}  

void inserte()  
{  
	struct node *ptr,*temp;  
	ptr= (struct node*)malloc(sizeof(struct node));      
	if(ptr==NULL)  
	{  
		printf("\nOVERFLOW");     
	}  
	else  
	{  
		printf("\nEnter value\n");  
		scanf("%d",&n);  
		ptr->data=n;  
		if(head==NULL)  
		{  
			ptr->next=NULL;  
       	        head=ptr;  
            		printf("\nNode inserted");  
       	 }  
        else  
        {  
          	temp=head;  
            	while(temp->next!=NULL)  
            	{  
                	temp=temp->next;  
            	}  
            	temp->next=ptr;  
            	ptr->next=NULL;  
            	printf("\nNode inserted");  
          
		}  
	} 
	printf("\n");
	main(); 
}  

void deletee()  
{  2=>21=>

	struct node *ptr,*ptr1;  
	if(head==NULL)  
	{  
		printf("\nlist is empty");  
	}  
	else if(head->next==NULL)  
	{  
		head=NULL;  
    		free(head);  
        	printf("\ndeleted\n");  
	}  
          
	else  
    	{  
		ptr=head;   
		while(ptr->next!=NULL)  
		{  
		    ptr1=ptr;  
		    ptr=ptr->next;  
		}  
		ptr1->next=NULL;  
		free(ptr);  
		printf("\nDeleted Node from the last\n");  
	}     
	printf("\n");
	main();   
}  

void insertp()  
	{   
	    struct node *ptr,*temp;  
	    ptr=(struct node *)malloc(sizeof(struct node));  
	    if(ptr==NULL)  
	    {  
		printf("\nOVERFLOW");  
	    }  
	    else  
	    {  
		printf("\nEnter element value");  
		scanf("%d",&n);  
		ptr->data=n;  
		printf("\nEnter the location after which you want to insert ");  
		scanf("\n%d",&loc);  
		temp=head;  
		for(i=0;i<loc;i++)  
		{  
		    temp=temp->next;  
		    if(temp==NULL)  
		    {  
		        printf("\ncan't insert\n");  
		        return;  
		    }  
		  
		}  
		ptr->next=temp->next;   
		temp->next=ptr;   
		printf("\nNode inserted");  
	    }  
	    printf("\n");
	    main();      
}  
void deletep()  
{  
	    struct node *ptr,*ptr1;      
	    printf("\n Enter the location of the node after which you want to delete\n");  
	    scanf("%d",&loc);  
	    ptr=head;  
	    for(i=0;i<loc;i++)  
	    {  
		ptr1=ptr;       
		ptr=ptr->next;  
		      
		if(ptr==NULL)  
		{  
		    printf("\nCan't delete");  
		    return;  
		}  
	    }  
	    ptr1->next=ptr->next;  
	    free(ptr);  
	    printf("\nDeleted node");  
	    printf("\n");
	    main(); 
} 
void search()  
{  
	    struct node *ptr;  
	    ptr=head;   
	    if(ptr==NULL)  
	    {  
		printf("\nEmpty List\n");  
	    }  
	    else  
	    {   
		printf("\nEnter item which you want to search\n");   
		scanf("%d",&n);  
		while(ptr!=NULL)  
		{  
		    if(ptr->data==n)  
		    {  
		        printf("item found at location %d ",i);  
		        flag=0;  
		    }   
		    else  
		    {  
		        flag=1;  
		    }  
		    i++;  
		    ptr=ptr->next;  
		}  
		if(flag==1)  
		{  
		    printf("Item not found\n");  
		}  
	    }  
	printf("\n");
	main();    		  
}  
