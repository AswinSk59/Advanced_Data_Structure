#include<stdio.h>
#include<stdlib.h>

struct node   
{  
    int data; 
    struct node *next;   
}; 

struct node *top;

int menu();
void push();
void pop();
void display();
void peek();


int n,choice;
int main(){
	printf("\n1.push\n2.pop\n3.display\n4.peek\n5.Exit");
	menu();
}

int menu(){
	printf("\n Enter your choice: ");
	scanf("%d",&choice);
	switch(choice)
	{
	case 1:push();
		break;
	case 2:pop();
		break;
	case 3:display();
		break;
	case 4:peek();
		break;
	case 5:
		exit(1);
	default:
		printf("Enter valid choice\n");
		menu();
	}
}

void push()
{
	    
	struct node *ptr;
	ptr=(struct node *)malloc(sizeof(struct node));
	if(ptr==NULL)
	{
		printf("Not able to push the element");
	}
	else
	{
		printf("Enter the value: ");
		scanf("%d", &n);
		ptr->data=n;
	}

	if(top==NULL)
	{
		ptr->next=NULL;
		top=ptr;
		printf("Item pushed\n");
	}
	else
	{
		ptr->next=top;
		top=ptr;
		printf("Item pushed\n");
	}
	menu();
}

void display()
{
	struct node *ptr=top;
	if(ptr==NULL)
	{
		printf("Stack is empty\n");
	}
	else
	{
		printf("Printing Stack elements:\n");
	while(ptr!=NULL)
	{	
		printf("|%d|\n",ptr->data);
		ptr=ptr->next;
	}
	}
	menu();
}

void pop()
{
	struct node *ptr,*ptr1;
	if(top==NULL)
	{
		printf("Underflow\n");
	}
	else
	{
	ptr=top;  
	top=ptr->next;  
	free(ptr);  
	printf("Item popped\n");
	}
	menu();
}

void peek()
{
	if(top==NULL)
	{
		printf("Stack is underflow!!!\n");
	}
	else{
	n=top->data;
	printf("Top most element is %d\n",n);
	}
	menu();
}
